<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelOrganisasi extends Model
{
    //
    protected $table = 'tb_organisasi';
    public $timestamps = false; 
}
