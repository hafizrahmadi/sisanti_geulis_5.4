<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelInstruksiCamat extends Model
{
    //
    protected $table = 'tb_instruksi_camat';

}
