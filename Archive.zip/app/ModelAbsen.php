<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelAbsen extends Model
{
    //
    protected $table = 'tb_absen';

}
