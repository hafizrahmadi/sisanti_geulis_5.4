<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelFeedbackSuratMasuk extends Model
{
    //
    protected $table = 'tb_feeback_surat_masuk';

}
