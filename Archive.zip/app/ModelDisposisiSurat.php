<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelDisposisiSurat extends Model
{
    //
    protected $table = 'tb_disposisi_surat';

}
