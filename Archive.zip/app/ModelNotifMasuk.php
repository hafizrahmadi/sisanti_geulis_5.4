<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelNotifMasuk extends Model
{
    //
    protected $table = 'tb_notif_masuk';
}
