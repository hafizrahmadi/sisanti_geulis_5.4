<?php $__env->startSection('css'); ?>
<style type="text/css">
  .td_limit {
     max-width: 50px;
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
    <h1>Absen Karyawan</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Absen Karyawan</li>
      </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Default box -->
    <div class="box" >
        <div class="box-header with-border">
            <h3 class="box-title">Absen <?php echo e(session('username')); ?></h3>
            <div class="box-tools pull-right">
                <!-- <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button> -->
            </div>
        </div>
        <div class="box-body" id="body-absen">

        </div>
        <div class="box-footer" id="footer-absen">
                
        </div>
        <div class="overlay div_loading" id="loading"><i class="fa fa-refresh fa-spin"></i></div>
        <!-- <div class="box-footer">

        </div> --><!-- /.box-footer-->
    </div><!-- /.box -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('outside-content'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<link rel="stylesheet" href="<?php echo e(asset('file_assets/adminlte/bower_components/datatables.net-bs/css/dataTables.bootstrap.css')); ?>">
<!-- DataTables -->
<script src="<?php echo e(asset('file_assets/adminlte/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('file_assets/adminlte/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>

<script type="text/javascript">
    var status_absen = null;
    $(document).ready(function() {
        getStatusAbsen();
        // getListJabatan();

    });

  function getStatusAbsen(){
    $.ajax({
                url: "<?php echo e(url('/api/status_absen/')); ?>"+"/"+"<?php echo e(session('id_user')); ?>",
                type: "GET",
                data: {
                },
                beforeSend: function() {
                  $('#loading').show();
                },
                success: function(dt) {
                  // dt = JSON.parse(data);
                  console.log(dt);
                  content = '';
                  if (dt.status=='Failed') {
                    content+='<div class="form-group">'+
                      '<label for="exampleInputEmail1">Nama</label>'+
                      '<div>'+"<?php echo e(session('nama_lengkap')); ?>"+'</div>'+
                    '</div>';
                    content+='<div class="form-group">'+
                      '<label for="exampleInputEmail1">NPK</label>'+
                      '<div>'+"<?php echo e(session('npk')); ?>"+'</div>'+
                    '</div>';
                    content+='<div class="form-group">'+
                      '<label for="exampleInputEmail1">Jabatan</label>'+
                      // '<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">'+
                      '<div>'+"<?php echo e(session('nama_jabatan')); ?>"+'</div>'+
                    '</div>';
                    content+='<div class="form-group">'+
                      '<label for="exampleInputEmail1">Status Absen</label>'+
                      // '<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">'+
                      '<div>Belum ada absen</div>'+
                    '</div>';
                    content+='<div class="form-group">'+
                      '<label for="exampleInputEmail1">Absen Terakhir</label>'+
                      // '<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">'+
                      '<div>Belum ada absen</div>'+
                    '</div>';
                  }else if (dt.status=='Success') {
                    content+='<div class="form-group">'+
                      '<label for="exampleInputEmail1">Nama</label>'+
                      '<div>'+"<?php echo e(session('nama_lengkap')); ?>"+'</div>'+
                    '</div>';
                    content+='<div class="form-group">'+
                      '<label for="exampleInputEmail1">NPK</label>'+
                      '<div>'+"<?php echo e(session('npk')); ?>"+'</div>'+
                    '</div>';
                    content+='<div class="form-group">'+
                      '<label for="exampleInputEmail1">Jabatan</label>'+
                      // '<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">'+
                      '<div>'+"<?php echo e(session('nama_jabatan')); ?>"+'</div>'+
                    '</div>';
                    content+='<div class="form-group">'+
                      '<label for="exampleInputEmail1">Status Absen</label>'+
                      // '<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">'+
                      '<div>'+dt.data.status_absen+'</div>'+
                    '</div>';
                    content+='<div class="form-group">'+
                      '<label for="exampleInputEmail1">Absen Terakhir</label>'+
                      // '<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">'+
                      '<div>'+dt.data.tanggal_absen+' ('+dt.data.jam_absen+')</div>'+
                    '</div>';
                  }

                  $('#body-absen').html(content);

                  ctn = '';
                  if (dt.status=='Failed') {
                    status_absen= 'Masuk';
                    ctn+='<button type="submit" onclick="submitAbsen()" class="btn btn-teal"><i class="fa fa-sign-in"></i> Absen Masuk</button>';
                  }else{
                    if (dt.data.status_absen=='Masuk') {
                      status_absen= 'Keluar';
                      ctn+='<button type="submit" onclick="submitAbsen()" class="btn btn-teal"><i class="fa fa-sign-in"></i> Absen Keluar</button>';
                    }else{
                      status_absen= 'Masuk';
                      ctn+='<button type="submit" onclick="submitAbsen()" class="btn btn-teal"><i class="fa fa-sign-in"></i> Absen Masuk</button>';
                    }
                    
                  }

                  $('#footer-absen').html(ctn);
                },
                complete: function() {

                  $('#loading').hide();
                },
                error: function() {
                    alert("Memproses data gagal !");
                }
            });
  }

  function submitAbsen(){
    $.ajax({
               url: "<?php echo e(url('/api/post_absen/')); ?>",
               type: "POST",
               data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                  'user_id': "<?php echo e(session('id_user')); ?>",
                  'status_absen':status_absen
               },
               beforeSend: function() {
                 console.log({
                   _token: '<?php echo e(csrf_token()); ?>',
                  'user_id': "<?php echo e(session('id_user')); ?>",
                  'status_absen':status_absen
                 });


               },
               success: function(data) {
                    // alert(data);
                    if (data.status=='Success') {
                        alert('Absen berhasil!');
                    }else{
                        alert('Absen gagal!');
                    }
               },
               complete: function() {
                 getStatusAbsen();
               },
               error: function() {
                   alert("Memproses data gagal !");
               }
           });
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>